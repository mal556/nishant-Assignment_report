Assignment 3: Chirag Mali

Submitting Date: 23/08/2024

Everything is followed as per step : Yes

Assignment Level : Medium

Code Quality Maintained : Yes
